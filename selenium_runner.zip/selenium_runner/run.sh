#!/bin/bash

cd tests/

echo "Compiling test cases"
javac -cp selenium.jar Generator.java

echo "Packing jar"
jar cmf manifest generator.jar Generator.class selenium.jar

echo "Executing jar"
java -jar generator.jar





