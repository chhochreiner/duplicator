#!/bin/bash

cd tests/

echo "Compiling test cases"
javac -cp selenium.jar Generator.java

echo "Packing jar"
jar cmf manifest generator.jar Generator.class images
echo "Executing jar"
java -jar generator.jar




#todo execute zip file