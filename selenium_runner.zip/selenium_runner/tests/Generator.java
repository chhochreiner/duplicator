import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Scanner;
import java.util.List;
import java.net.URISyntaxException;
import java.io.File;
public class Generator  {
public static void main(String[] args) {
Scanner scanner = new Scanner( System.in );
WebDriver driver = new FirefoxDriver();
    WebElement element = null;        System.out.println("Start registration of Backup User");
    
        driver.get("http://btbas.org/testpage/register.html");

        element = driver.findElement(By.name("firstname"));
        element.sendKeys("Backup");
      
        element = driver.findElement(By.name("lastname"));
        element.sendKeys("User");
        
        element = driver.findElement(By.name("email"));
        element.sendKeys("backup@test.com");

        element = driver.findElement(By.name("password"));
        element.sendKeys("password");
        
        element = driver.findElement(By.name("password_repeat"));
        element.sendKeys("password");

        System.out.println("please solve the captcha and press enter");

        scanner.nextLine();

        element = driver.findElement(By.name("submit"));
        element.click();

        System.out.println("Backup User was registered");
        

        System.out.println("Start login for Backup User");
    
        driver.get("http://btbas.org/testpage/login.html");

        element = driver.findElement(By.name("name"));
        element.sendKeys("backup@test.com");
      
        element = driver.findElement(By.name("password"));
        element.sendKeys("password");


        element = driver.findElement(By.name("submit"));
        element.click();

        System.out.println("Backup User was logged in");

        
        System.out.println("Edit details of Backup User");
    
        driver.get("http://btbas.org/testpage/profile.html");

        element = driver.findElement(By.name("location"));
        element.sendKeys("Vienna");
      
        element = driver.findElement(By.name("music"));
        element.sendKeys("some fancy music");

        element = driver.findElement(By.name("language"));
        element.sendKeys("$language");

        element = driver.findElement(By.id("day"));
        List<WebElement> options = element.findElements(By.tagName("option"));
        element.click();

  
        for (WebElement option : options) {
            if (option.getValue().equals("13")){
                option.setSelected();
                break;
            }
        }

        element = driver.findElement(By.id("month"));
        options = element.findElements(By.tagName("option"));
        element.click();

  
        for (WebElement option : options) {
            if (option.getValue().equals("7")){
                option.setSelected();
                break;
            }
            
        }

        element = driver.findElement(By.name("year"));
        element.sendKeys("2011");

		element = driver.findElement(By.id("avatar"));
		element.sendKeys(new File("images/avatar.jpg").getAbsolutePath());


        System.out.println("please check the data and press enter");

        scanner.nextLine();


        element = driver.findElement(By.name("submit"));
        element.click();

        System.out.println("data for Backup User was updated");


driver.quit();
}
}